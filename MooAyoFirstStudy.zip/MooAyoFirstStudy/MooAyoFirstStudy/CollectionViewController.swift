//
//  CollectionViewController.swift
//  MooAyoFirstStudy
//
//  Created by 박익범 on 2021/04/21.
//

import UIKit

class CollectionViewController: UIViewController{
    
    let images = ["mooayo.jpeg"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
}
